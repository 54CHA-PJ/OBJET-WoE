
package org.centrale.objet.WoE;

/**
 * L'entité qui implémente cette interface peut se déplacer dans le monde
 * 
 * @author ESPINOZA Mario
 * @author CRUZ Sacha
 */
public interface Deplacable {
    void seDeplacer(World w);
}
