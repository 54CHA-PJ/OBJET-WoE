package org.centrale.objet.WoE;

import java.io.IOException;

/**
 * La classe Projet_WOE contient la fonction principale qui initialise le jeu.
*@author CRUZ Sacha
*@author ESPINOZA Mario
*/
public class Projet_WOE {
    public static void main(String[] args) throws IOException {
        //TestWoE.main(args);
        WorldSaveTools.init();
    }
}
