package org.centrale.objet.WoE;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * La classe WorldSaveTools offre des outils pour initialiser, enregistrer et jouer une partie de WoECN
 * 
 * @author ESPINOZA Mario.
 * @author CRUZ Sacha.
 */
public class WorldSaveTools {

    WorldSaveTools(){}

    // --------------------------------------------------------------------------------------------------------
    // Méthodes
    // --------------------------------------------------------------------------------------------------------

    public static void init() throws IOException {
        String nomFichier1 = "Sauvegarde-WoE.txt";
        String nomFichier2 = "Sauvegarde-WoE-2.txt";
        World world = new World();

        System.out.println("\n=============================");
        System.out.println("World of ECN - Initialisation ");
        System.out.println("=============================\n");
        System.out.print("Menu principal :");
        System.out.print("\n[1] Nouveau Monde\n[2] Ouvrir sauvegarde 1(exemple du TP6) : 'Sauvegarde-WoE.txt'\n[3] Ouvrir sauvegarde 2(sauvegarde locale) : 'Sauvegarde-WoE-2.txt'\n");

        int i = 0;
        do {
            try {
                Scanner sc = new Scanner(System.in);
                i = sc.nextInt();
            } catch (Exception e) {
                System.out.print("Réessayez svp :\n");
            }
        } while (i < 1);

        switch (i) {
            case 1:
                System.out.print("\nGénération du nouveau monde");
                world.init();
                jeu(world);
                break;
            case 2:
                System.out.print("\nOuverture de la sauvegarde 1 :" + nomFichier1);
                try {
                    populate(world, read(nomFichier1));
                    jeu(world);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    System.out.print("\nFermeture du jeu");
                }
                break;
            case 3:
                System.out.print("\nOuverture de la sauvegarde 2 :" + nomFichier2);
                try {
                    populate(world, read(nomFichier2));
                    jeu(world);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    System.out.print("\nFermeture du jeu");
                }
                break;
            default:
                System.out.print("\nFermeture du jeu");

        }
    }

    public static void jeu(World w) throws IOException{
        System.out.println("\n -------------------- DEBUT DU JEU -------------------- \n");
            int tour = 0;
            Boolean jeu;
            do {
                jeu = w.tour_de_jeu(tour);
                tour++;
            } while (jeu);
    }

    public static ArrayList<String> read(String nomFichier) {
        String ligne;
        ArrayList<String> lignesFichier = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(nomFichier);
            BufferedReader br = new BufferedReader(fileReader);
            while ((ligne = br.readLine()) != null) {
                //System.out.println(ligne);
                lignesFichier.add(ligne);
            }
        } catch (FileNotFoundException e) {
            //e.printStackTrace();
            System.out.println("\n=========== ERREUR ===========\n");
            System.out.println("Assurez-vous d'avoir ce fichier dans le répértoire du jeu !");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lignesFichier;
    }


    /**
     * Lit les données du fichier de sauvegarde, remplit monde avec les entités correspondantes
     * et remplit l'inventaire du joueur principal.
     * @param w Le monde à peupler avec les entités lues depuis le fichier de sauvegarde.
     * @param texte Les données lues depuis le fichier de sauvegarde.
     */
    public static void populate(World w, ArrayList<String> texte) {
        // FORMES DES LA LISTE "listatt" :
        // (On pourrait optimiser l'ordre des attributs pour que les fonctions soient moins lourdes)
        //                       0    1       2      3     4       5        6        7          8     9       10
        // Archer           - Classe nom    ptVie degAtt ptPar   pageAtt pagePar distAttMax     x     y    nbFleches
        // Guerrier         - Classe nom    ptVie degAtt ptPar   pageAtt pagePar distAttMax     x     y
        // Paysan           - Classe nom    ptVie degAtt ptPar   pageAtt pagePar distAttMax     x     y
        // Loup             - Classe ptVie  degAtt ptPar pageAtt pagePar distAtt    x           y
        // Lapin            - Classe ptVie  degAtt ptPar pageAtt pagePar distAtt    x           y
        // Nuage            - Classe nom    toxici x     y
        // PotionSoin       - Classe nom    gPtVie x     y
        // Epee             - Classe nom    degAtt x     y       portee
        // Tajine           - Classe nom    tours  degAtt  ptPar   x       y
        // Champi           - Classe nom    tours  degAtt  ptPar   x       y
        int count = 0;
        for (String ligne : texte) {
            System.out.println(ligne);
            count++;
            ArrayList<Object> listatt = stringToList(ligne);
            try {
                String nomClasse = (String) listatt.get(0);
                Class<?> clazz = Class.forName(nomClasse);
                Object obj = clazz.getDeclaredConstructor().newInstance();
                if (obj instanceof Creature) {
                    Creature creature = (Creature) obj;
                    creature.readAttributs(listatt);
                    w.getListeCreatures().add(creature);
                    w.getPositionsOccupees().add(creature.getPos());
                } else if (obj instanceof Objet) {
                    Objet objet = (Objet) obj;
                    objet.readAttributs(listatt);
                    if (objet instanceof NuageToxique) {
                        w.getListeObjets().add(objet);
                    } else {
                        w.getPlayer1().getInventaire().add(objet);
                    }
                } else {
                    System.out.println("Erreur à la lecture de la ligne " + count);
                    count--;
                }
            } catch (Exception e) {
                System.out.println("Erreur à la lecture de la ligne " + count);
                count--;
            }
        }
        System.out.println("\n=============================");
        System.out.println(count + " entités créées avec succès");
        System.out.println("=============================\n\n");
    }

    /**
     * Transforme une chaîne de caractères en une liste d'objets, en essayant de convertir les parties en entiers.
     * @param input La chaîne de caractères à transformer en liste d'objets.
     * @return Une liste d'objets résultant de la transformation de la chaîne d'entrée.
     */
    public static ArrayList<Object> stringToList(String input) {
        String[] parts = input.split(" ");
        ArrayList<Object> list = new ArrayList<>();

        for (String part : parts) {
            try {
                int intValue = Integer.parseInt(part);
                list.add(intValue);
            } catch (NumberFormatException e) {
                list.add(part);
            }
        }
        return list;
    }
}